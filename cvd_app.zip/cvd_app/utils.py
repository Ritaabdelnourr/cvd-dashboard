
import pandas as pd, functools, pathlib
DATA = pathlib.Path(__file__).parent/'data'
FCSV = 'CardioVascular disease data.csv'

@functools.lru_cache(maxsize=1)
def load_monthly():
    return pd.read_csv(DATA/FCSV,
                       parse_dates=['year_month'],
                       dtype={'sex':'category','age_band':'category',
                              'residence':'category'})

@functools.lru_cache(maxsize=1)
def load_patients():
    path = DATA/'patient_level.parquet'     # drop in later if you have it
    return pd.read_parquet(path) if path.exists() else None
