
import streamlit as st, plotly.express as px, pandas as pd
from utils import load_monthly

st.set_page_config('CVD Dashboard', layout='wide')
df = load_monthly()

# global sidebar filters
st.sidebar.header('Filters')
sex_f = st.sidebar.multiselect('Sex', ['M','F'], default=['M','F'])
age_f = st.sidebar.multiselect('Age band', df.age_band.cat.categories,
                               default=list(df.age_band.cat.categories))
res_f = st.sidebar.multiselect('Residence', sorted(df.residence.unique()),
                               default=list(df.residence.unique()))
filt  = df[df.sex.isin(sex_f)&df.age_band.isin(age_f)&df.residence.isin(res_f)]

st.title('🫀 Cardiovascular Surgery Cohort – Lebanon')
latest = filt.year_month.max()
curr   = filt.loc[filt.year_month==latest,'cvd_cases'].sum()
prev   = filt.loc[filt.year_month==latest-pd.offsets.MonthEnd(),'cvd_cases'].sum()
delta  = (curr-prev)/prev if prev else 0

c1,c2 = st.columns(2)
c1.metric('CVD cases (latest month)', f'{curr:,}', f'{delta:+.1%}')
c2.metric('Time span', f'{filt.year_month.min():%Y-%m} → {latest:%Y-%m}')

trend = filt.groupby('year_month')['cvd_cases'].sum().reset_index()
st.plotly_chart(px.line(trend, x='year_month', y='cvd_cases', markers=True,
                        title='Monthly CVD cases'),
                use_container_width=True)
