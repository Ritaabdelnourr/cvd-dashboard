
import streamlit as st, geopandas as gpd, plotly.express as px, pandas as pd
from utils import load_monthly, DATA
if not (DATA/'lebanon.geojson').exists():
    st.info('Upload lebanon.geojson to cvd_app/data/ to enable this map.')
    st.stop()
geo = gpd.read_file(DATA/'lebanon.geojson')
df  = load_monthly()
sex_f = st.sidebar.session_state['sex']; age_f = st.sidebar.session_state['age_band']
filt = df[df.sex.isin(sex_f)&df.age_band.isin(age_f)]
month = st.selectbox('Month', filt.year_month.sort_values().unique()[::-1])
sub = filt[filt.year_month==pd.to_datetime(month)]
agg = sub.groupby('residence')['cvd_cases'].sum().reset_index()
mapdf = geo.merge(agg, left_on='NAME_EN', right_on='residence', how='left')
mapdf['cvd_cases'] = mapdf['cvd_cases'].fillna(0)
fig = px.choropleth(mapdf, geojson=mapdf.geometry, locations=mapdf.index,
                    color='cvd_cases', hover_name='NAME_EN',
                    color_continuous_scale='Reds')
fig.update_geos(fitbounds='locations', visible=False)
st.title('🗺️ Geographic burden'); st.plotly_chart(fig, use_container_width=True)
