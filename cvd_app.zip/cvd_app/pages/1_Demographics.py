
import streamlit as st, plotly.express as px
from utils import load_monthly
df = load_monthly()
sex_f = st.sidebar.session_state['sex']; age_f=st.sidebar.session_state['age_band']; res_f=st.sidebar.session_state['residence']
filt = df[df.sex.isin(sex_f)&df.age_band.isin(age_f)&df.residence.isin(res_f)]
st.title('👥 Age–sex pyramid')
yr = st.slider('Year', int(df.year_month.dt.year.min()),
                         int(df.year_month.dt.year.max()),
                         value=int(df.year_month.dt.year.max()))
sub = filt[filt.year_month.dt.year==yr]
pivot = (sub.pivot_table(index='age_band', columns='sex',
                         values='cvd_cases', aggfunc='sum')
            .fillna(0).sort_index())
pivot['F'] = -pivot['F']
fig = px.bar(pivot, orientation='h', height=520, title=str(yr),
             labels={'value':'Cases','age_band':'Age band'})
fig.update_layout(yaxis={'categoryorder':'array','categoryarray':pivot.index[::-1]})
st.plotly_chart(fig, use_container_width=True)
