
import streamlit as st, pandas as pd
from utils import load_patients
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import roc_auc_score
patients = load_patients()
if patients is None or 'ICU stay' not in patients.columns:
    st.info('patient_level.parquet not provided.')
    st.stop()
patients['icu_gt5'] = (patients['ICU stay']>5).astype(int)
X = patients[['cvd_flag','age','clampage','fe']].fillna(0); y=patients['icu_gt5']
Xtr,Xts,ytr,yts = train_test_split(X,y,test_size=0.2,random_state=42,stratify=y)
auc = roc_auc_score(yts, GradientBoostingClassifier().fit(Xtr,ytr).predict_proba(Xts)[:,1])
st.metric('Hold-out AUC', f'{auc:.3f}')
