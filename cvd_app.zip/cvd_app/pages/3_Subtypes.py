
import streamlit as st, plotly.express as px
from utils import load_monthly
df = load_monthly()
if not {'htn','cad','pad','dm'}.issubset(df.columns):
    st.info('Subtype columns not present.')
    st.stop()
sex_f = st.sidebar.session_state['sex']; age_f=st.sidebar.session_state['age_band']; res_f=st.sidebar.session_state['residence']
filt = df[df.sex.isin(sex_f)&df.age_band.isin(age_f)&df.residence.isin(res_f)]
subtype = st.selectbox('Subtype', ['htn','cad','pad','dm'])
trend = filt.groupby('year_month')[subtype].sum().reset_index()
st.title('🩺 '+subtype.upper()); st.plotly_chart(px.area(trend, x='year_month', y=subtype), use_container_width=True)
